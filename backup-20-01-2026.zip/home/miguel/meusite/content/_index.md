---
title: "Initium"
description: "Principia prima quibus omnis inquisitio ordinatur."
---

O ser é inteligível.

A verdade é a conformidade do intelecto ao que é.

A razão humana não cria a ordem, mas a reconhece.

Toda confusão teórica procede da inversão desses princípios:
quando o pensamento precede o ser,
quando o sentido é separado da coisa,
quando a vontade usurpa o lugar do intelecto.

Este sítio se funda na tradição metafísica clássica,
segundo a qual:

o ente é anterior ao conceito;

o fim governa os meios;

a hierarquia é constitutiva do real.

O que aqui se escreve não visa inovação,
mas retidão.

Pensar bem é submeter-se à ordem do ser.

## Últimos tratados

